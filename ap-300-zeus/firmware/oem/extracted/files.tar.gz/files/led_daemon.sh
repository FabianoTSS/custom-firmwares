#!/bin/sh /etc/rc.common

START=11
STOP=98

LED_ON=16
LED_OFF=8
COLORS="RED GREEN YELLOW BLUE MAGENTA CYAN WHITE BLACK"
MODES="ON OFF BLINK TOGGLE RANDOM"

to_upper_case()
{
	echo "$1" | awk '{for(i=1;i<=NF;i++){ $i=toupper($i) }}1'
}

load_led_params()
{
	LED_MODE="$(to_upper_case $1)"
	LED_COLOR_A="$(to_upper_case $2)"
	LED_COLOR_B="$(to_upper_case $3)"
	[ -n "$4" ] && LED_DELAY_ON="$4" || LED_DELAY_ON="1"
	[ -n "$5" ] && LED_DELAY_OFF="$5" || LED_DELAY_OFF="1"
}

load_led_file()
{
	[ -f /usr/sbin/cal/led_schedule ] || {
		error_msg "LED schedule file does not exist!"
		exit 1
	}
	led_schedule="$(cat /usr/sbin/cal/led_schedule)"
	led_schedule="$(to_upper_case $led_schedule)"
	[ -f /usr/sbin/cal/led_ctrl ] || {
		error_msg "LED control file does not exist!"
		exit 1
	}
	load_led_params $(cat /usr/sbin/cal/led_ctrl)
}

get_led_colors()
{
	LED_COLOR_A="$(cat /usr/sbin/cal/led_ctrl | tr '[:lower:]' '[:upper:]')"
	if dereference_color "$LED_COLOR_A"; then
		echo "Color $LED_COLOR_A is in the list"
	else
		echo "Color $LED_COLOR_A is not in the list"
	fi
}

led_red()
{
	[ "$1" = "OFF" ] && led="$LED_OFF" || led="$LED_ON"
	echo $led > /sys/class/leds/ap953x\:red\:signal3/delay_on
	echo $led > /sys/class/leds/ap953x\:red\:signal3/delay_off
}

led_green()
{
	[ "$1" = "OFF" ] && led="$LED_OFF" || led="$LED_ON"
	echo $led > /sys/class/leds/ap953x\:green\:signal2/delay_on
	echo $led > /sys/class/leds/ap953x\:green\:signal2/delay_off
}

led_blue()
{
	[ "$1" = "OFF" ] && led="$LED_OFF" || led="$LED_ON"
	echo $led > /sys/class/leds/ap953x\:blue\:signal1/delay_on
	echo $led > /sys/class/leds/ap953x\:blue\:signal1/delay_off
}

led_yellow()
{
	led_red "$1"
	led_green "$1"
}

led_magenta()
{
	led_red "$1"
	led_blue "$1"
}

led_cyan()
{
	led_green "$1"
	led_blue "$1"
}

led_white()
{
	led_red "$1"
	led_blue "$1"
	led_green "$1"
}

led_black()
{
	led_off
}

print_error_msg()
{
	>&2 echo -e "\033[0;31m$1\033[0m"
}

led_colorize()
{
	if ! dereference_color "$1"; then
		print_error_msg "Cannot colorize led with an invalid color '$1'!"
		return 1
	fi

	case $1 in
		RED) led_red "$2" ;;
		BLUE) led_blue "$2" ;;
		GREEN) led_green "$2" ;;
		YELLOW) led_yellow "$2" ;;
		CYAN) led_cyan "$2" ;;
		MAGENTA) led_magenta "$2" ;;
		WHITE) led_white "$2" ;;
		BLACK) led_black ;;
	esac
}

led_mode_act()
{
	if ! dereference_mode "$1"; then
		print_error_msg "Cannot operate led with an invalid mode of operation '$1'!"
		return 1
	fi

	case $1 in
		ON) led_colorize $LED_COLOR_A;
			sleep 1; ;;
		OFF) led_off;
			 sleep 1; ;;
		RANDOM) led_red;
				sleep 1;
				led_red "OFF";
				led_blue;
				sleep 1;
				led_blue "OFF";
				led_green;
				sleep 1;
				led_green "OFF"; ;;
		TOGGLE) led_colorize "$LED_COLOR_A";
				sleep $LED_DELAY_ON;
				led_off;
				led_colorize "$LED_COLOR_B";
				sleep $LED_DELAY_OFF;
				led_off; ;;
		BLINK) led_colorize "$LED_COLOR_A";
			   usleep 700000;
			   led_colorize "$LED_COLOR_A" "OFF";
			   usleep 300000; ;;
	esac
}

led_off()
{
	led_red "OFF"
	led_green "OFF"
	led_blue "OFF"
}

get_led_mode()
{
	LED_MODE="$(cat /usr/sbin/cal/led_mode | tr '[:lower:]' '[:upper:]')"
	pos=$(expr match "$COLORS" ".*$LED_COLOR_A.*")
	if [ "$LED_MODE" = "$MODES" ]; then
        echo "Mode is in the list"
    else
        echo "Mode is not in thelist"
    fi
	return 0
}

dereference_color()
{
	pos=$(expr match "$COLORS" ".*$1.*")
	test "$pos" -gt "0"
	return $?
}

dereference_mode()
{
    for mode in $MODES; do
        if [ "$1" = "$mode" ]; then
            echo $mode
            return 0
        fi
    done
	return 1
}

start_daemon()
{
	led_off
	while true; do
		load_led_file
		[ "$led_schedule" = "STANDBY" ] && led_off && continue
		if [[ "$LED_MODE_AUX" != "$LED_MODE" || "$LED_COLOR_A_AUX" != "$LED_COLOR_A_AUX" || "$LED_COLOR_B" != "$LED_COLOR_B_AUX" ]]; then
			led_off
		fi
		LED_MODE_AUX=$LED_MODE
		LED_COLOR_A_AUX=$LED_COLOR_A
		LED_COLOR_B_AUX=$LED_COLOR_B
		led_mode_act "$LED_MODE"
	done
}

start()
{
	start_daemon&
}

stop()
{
	led_off
	kill -9 $(ps | grep "led_daemon" | grep -v grep | awk '{ print $1 }')
	exit 0

}
