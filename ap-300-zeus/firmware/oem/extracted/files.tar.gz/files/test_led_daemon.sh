#!/bin/sh

echo "ON RED"
echo "ON RED" > /usr/sbin/cal/led_ctrl
sleep 8
echo "ON GREEN"
echo "ON GREEN" > /usr/sbin/cal/led_ctrl
sleep 8
echo "ON BLUE"
echo "ON BLUE" > /usr/sbin/cal/led_ctrl
sleep 8
echo "BLINK GREEN"
echo "BLINK GREEN" > /usr/sbin/cal/led_ctrl
sleep 8
echo "BLINK BLUE"
echo "BLINK BLUE" > /usr/sbin/cal/led_ctrl
sleep 8
echo "BLINK RED"
echo "BLINK RED" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE GREEN BLUE"
echo "TOGGLE GREEN BLUE" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE GREEN RED"
echo "TOGGLE GREEN RED" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE RED BLUE"
echo "TOGGLE RED BLUE" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE GREEN YELLOW"
echo "TOGGLE GREEN YELLOW" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE GREEN CYAN"
echo "TOGGLE GREEN CYAN" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE GREEN MAGENTA"
echo "TOGGLE GREEN MAGENTA" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE GREEN WHITE"
echo "TOGGLE GREEN WHITE" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE RED YELLOW"
echo "TOGGLE RED YELLOW" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE RED CYAN"
echo "TOGGLE RED CYAN" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE RED MAGENTA"
echo "TOGGLE RED MAGENTA" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE RED WHITE"
echo "TOGGLE RED WHITE" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE BLUE YELLOW"
echo "TOGGLE BLUE YELLOW" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE BLUE CYAN"
echo "TOGGLE BLUE CYAN" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE BLUE MAGENTA"
echo "TOGGLE BLUE MAGENTA" > /usr/sbin/cal/led_ctrl
sleep 8
echo "TOGGLE BLUE WHITE"
echo "TOGGLE BLUE WHITE" > /usr/sbin/cal/led_ctrl
sleep 8
echo "OFF"
echo "OFF" > /usr/sbin/cal/led_ctrl
sleep 8
echo "RANDOM"
echo "RANDOM" > /usr/sbin/cal/led_ctrl
sleep 8
