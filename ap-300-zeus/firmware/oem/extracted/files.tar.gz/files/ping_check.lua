#!/bin/env lua

-- START=98
-- STOP=98

require 'socket'
require 'uci'
require 'ubus'

-- Parameters used by Connectivity Check Service
local wait_interval = 5 

port_list = {
	dns = 23,
	http = 80,
	https = 413
}

local address_list = {
	dns = {
		google1 = '8.8.8.8',
		openDNS1 = '208.67.222.222',
	},
	http = {
		google = 'www.google.com',
		globo = 'www.globo.com',
	}
}

local function report_connectivity(internet)
        -- Report Connectivity Test Result
	local conn = ubus.connect()
	conn:send("itb", {["internet"] = internet})
end

local function checkAddressByMethod(method, address, port)
	if method == "ping" then return (os.execute("ping -W " .. wait_interval .. " -c 1 " .. address) == 0)
	elseif method == "socket" then return (socket.connect(address, port) ~= nil)
	else return false
	end
end

-- Check Connection Routine
local function check_internet()
	local internet = true
	local method_status = true
	for _,protocol in pairs({"dns","http"}) do
		local addresses = address_list[protocol]
		local prot_status = false
		local port = port_list[protocol]
		for _,address in pairs(addresses) do
			local has_route = (os.execute("ip route get " .. address) == 0)
			if has_route and not prot_status then
				if checkAddressByMethod("ping", address, port) or
					checkAddressByMethod("socket", address, port) then
					prot_status = true
				end
			end
		end
		if not prot_status then
			return false
		end
	end
	return false
end

local function check_connectivity()
	while true do
		report_connectivity(check_internet())
	end
end

check_connectivity()
