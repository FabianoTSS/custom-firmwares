#!/usr/bin/env lua

require 'json'
require 'ubus'

if arg[1] and arg[2] and arg[3] and arg[4] then
    local conn = ubus.connect()
    if not conn then                                
        error("Failed to connect to ubusd")         
    end                                    
    data = conn:call(arg[1], arg[2], json.decode(arg[3]))

	path = 'print(json.encode(data' .. arg[4] .. '))'
	loadstring(path)()
end
