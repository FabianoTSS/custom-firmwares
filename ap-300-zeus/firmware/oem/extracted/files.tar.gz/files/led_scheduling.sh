#!/bin/sh /etc/rc.common

START=12
STOP=99

USE_PROCD=1

# Store the time step to check for LED schedule, current status and update LED
time_step=2

# Store all the possible LED schedule modes
LED_schedule_modes="ACTIVE STANDBY STANDBY_TIME ACTIVE_TIME STANDBY_DATE ACTIVE_DATE ACTIVE_DOW STANDBY_DOW"

print_error_msg()
{
	>&2 echo -e "\033[0;31m$1\033[0m"
}

to_upper_case()
{
	echo "$1" | awk '{for(i=1;i<=NF;i++){ $i=toupper($i) }}1'
}

dereference_led_schedule_mode()
{
	pos=$(expr match "$LED_schedule_modes" ".*$1.*")
	test "$pos" -gt "0" 
	return $?
}

dereference_day_of_week()
{
	case "$1" in
		sun) echo 0;;
		mon) echo 1;;
		tue) echo 2;;
		wed) echo 3;;
		thu) echo 4;;
		fri) echo 5;;
		sat) echo 6;;
		*) return 1 ;;
	esac
	return 0
}

is_led_schedule_enabled()
{
	# Check if led scheduling is enabled
	led_schedule_enabled="$(uci get -q leds.scheduling.enabled)"
	echo "led_schedule_enabled '$led_schedule_enabled'"
	[ -z led_schedule_enabled ] && return 1 
	[ "$led_schedule_enabled" = "1" ] || return 1
	return 0
}

get_led_schedule_mode()
{
	uci_leds_mode="$(uci get -q leds.scheduling.mode)"
	led_schedule_mode="$(to_upper_case $uci_leds_mode)"
	if [ -z "$led_schedule_mode" ] || ! dereference_led_schedule_mode "$led_schedule_mode"; then
		print_error_msg "Invalid led schedule mode '$led_schedule_mode'!"
		return 1
	fi
	return 0
}

get_time_option()
{
	pos_date=$(expr match "$led_schedule_mode" ".*DATE$")
	pos_time=$(expr match "$led_schedule_mode" ".*TIME$")
	pos_dow=$(expr match "$led_schedule_mode" ".*DOW")

	[ "$pos_date" -eq "0" ] && [ "$pos_time" -eq "0" ] && [ "$pos_dow" -eq "0" ] && return 1
	[ "$pos_date" -gt "0" ] && echo "DATE"
	[ "$pos_time" -gt "0" ] && echo "TIME"
	[ "$pos_dow" -gt "0" ] && echo "DOW"
	return 0
}

get_schedule_action()
{
	pos_active=$(expr match "$led_schedule_mode" "\bACTIVE.*")
	pos_standby=$(expr match "$led_schedule_mode" "\bSTANDBY.*")
	[ "$pos_active" -eq "0" ] && [ "$pos_standby" -eq "0" ] && return 1
	[ "$pos_active" -gt "0" ] && echo "ACTIVE"
	[ "$pos_standby" -gt "0" ] && echo "STANDBY"
	return 0
}

parse_schedule_mode_and_action()
{
	option="$(get_time_option)"
	action="$(get_schedule_action)"
}

get_now()
{
	option="$(get_time_option)"
	[ "$?" -eq "0" ] &&
	{
		if [ "$option" = "DATE" ]; then
			now="$(date +%Y%m%d%H%M)"
		else
			now="$(date +%H%M)"
		fi
	}
	echo "$now"
}

check_weekday_in_schedule()
{
	# If time option is not weekday, ignores
	[ "$option" = "DOW" ] || return 0

	today_weekday="$(date +%w)"
	get_schedule_day_of_week

    for weekday in $led_schedule_dow; do
		dow="$(dereference_day_of_week $weekday)"
        if [ "$today_weekday" = "$dow" ]; then
            return 0
        fi
    done
    return 1
}

# Function to get scheduled days of week (0 is Sunday and 6 Friday)
get_schedule_day_of_week()
{
	led_schedule_dow="$(uci get -q leds.scheduling.weekdays)"
}

get_complement_action()
{
	[ "$action" = "ACTIVE" ] && echo "STANDBY"
	[ "$action" = "STANDBY" ] && echo "ACTIVE"
	return 0
}

get_led_schedule()
{
	# Get schedule intervals
	intervals="$(uci get -q leds.scheduling.intervals)"


	if [ -z "$intervals" ]; then
		print_error_msg "Cannot have empty schedule intervals if mode is not ACTIVE neither STANDBY"
		return 1
	fi

	# Abort if scheduling information is invalid
	[ "$start" -ge "$end" ] && return 1

	return 0
}

get_current_led_schedule()
{
	# Get current LED schedule status
	led_schedule_status="$(cat /tmp/.led_schedule)"
}

record_led_schedule()
{
echo "recording led_schedule action $1!!!"
	[ "$1" == "ACTIVE" ] && master='on' || master='off'
	[ "$1" == "ACTIVE" ] && scheduled='1' || scheduled='0'
	ubus send led "{'master':'$master'}"
	echo "$1" > /tmp/.led_schedule
}

schedule_led()
{
	action="$(get_schedule_action)"
	complement_action="$(get_complement_action)"

	# First of all, check if action is simple mode (no schedule info required)
	[ "$1" = "SIMPLE" ] && { record_led_schedule "$action"; return 1; }

	# If time option is day of week schedule, check if today weekday is in the range
	if ! check_weekday_in_schedule ; then
		# Fake now and end times to force complement action
		end="0"
		now="1"
	fi

counter=0
for time in $intervals; do
	counter=$((counter+1))

	if [ "$((counter%2))" -eq 0 ]; then
		end="$time"
	else
		start="$time"
		continue
	fi

	# Then check if schedule is in between start and end times
	if [ "$start" -le "$now" ] && [ "$end" -ge "$now" ]; then
		[ "$led_schedule_status" == "$action" ]  || record_led_schedule "$action"
		return
	fi
done
[ "$led_schedule_status" == "$complement_action" ] || record_led_schedule "$complement_action"

}

start_schedule()
{
	if is_led_schedule_enabled && get_led_schedule_mode; then
		# If led schedule mode is only ACTIVE or STANDBY we don't need to check times
		if [ "$led_schedule_mode" = "ACTIVE" ] || [ "$led_schedule_mode" = "STANDBY" ]; then
			action_mode="SIMPLE"
		else
			if ! get_led_schedule; then
				continue
			fi
			get_current_led_schedule
			get_now
		fi
		schedule_led "$action_mode"
	else
		rm -rf /tmp/.led_schedule
	fi
}

reload_service ()
{
    start_schedule
}

service_triggers()
{
    procd_add_reload_trigger "leds"
}

start_service()
{
	start_schedule
}
