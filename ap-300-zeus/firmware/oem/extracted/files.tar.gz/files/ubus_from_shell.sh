#!/bin/sh
link_status=$(get_from_json network.device status "{}" ".eth0.carrier")
if [ "$link_status" == "true" ]; then
	echo "LINK IS UP"
else
	echo "LINK IS DOWN"
fi
