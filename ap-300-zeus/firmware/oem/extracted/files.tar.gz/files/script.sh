#!/bin/sh

wifi down
rmmod ath9k
rmmod ath9k_common
rmmod ath9k_hw
rmmod ath

ln -s /dev/mtdblock7 /dev/caldata

cd /tmp
export LD_LIBRARY_PATH=./:$LD_LIBRARY_PATH
tftp -g -r art.ko 192.168.1.99
tftp -g -r libanwi.so 192.168.1.99
tftp -g -r libar9287.so 192.168.1.99
tftp -g -r libar9300.so 192.168.1.99
tftp -g -r libcal-2p.so 192.168.1.99
tftp -g -r libfield.so 192.168.1.99
tftp -g -r liblinkAr9k.so 192.168.1.99
tftp -g -r libLinkQc9K.so 192.168.1.99
tftp -g -r libpart.so 192.168.1.99
tftp -g -r libqc98xx.so 192.168.1.99
tftp -g -r libtlvtemplate.so 192.168.1.99
tftp -g -r libtlvutil.so 192.168.1.99
tftp -g -r nart.out 192.168.1.99

mknod /dev/dk0 c 63 0
mknod /dev/dk1 c 63 1

insmod art.ko
chmod +x nart.out
./nart.out &
exit 0

