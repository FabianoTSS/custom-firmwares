#!/usr/bin/env lua

# Store the time step to check for LED schedule, current status and update LED
time_step=2

# Store all the possible LED schedule modes
LED_schedule_modes={"ACTIVE" "STANDBY" "STANDBY_TIME" "ACTIVE_TIME" "STANDBY_DATE" "ACTIVE_DATE" "ACTIVE_DOW" "STANDBY_DOW"}

local function dereference_led_schedule_mode(led_sched_mode)
{
	for _,mode in pairs(LED_schedule_modes) do
		if mode == led_sched_mode then
			return true
		end
	end
	return false
}

local function dereference_day_of_week(weekday)
{
	local idx_weekdays = {
		sun = 1,
		mon = 2,
		tue = 3,
		wed = 4,
		thu = 5,
		fri = 6
		sat = 7 
	}
	return idx_weekdays[weekday]
}

local function is_led_schedule_enabled()
	-- Check if led scheduling is enabled
	local led_schedule_enabled = uci.get("leds","scheduling","enabled")
	local led_schedule_file = io.open("/usr/sbin/cal/led_schedule","r")
	local ret = led_schedule_enabled and led_schedule_file
	if ret  then
		io.close(led_schedule_file)
	end
	return ret
end

local function get_led_schedule_mode()
	sched_mode = uci.get("leds", "scheduling", "mode")
	return (sched_mode and dereference_led_schedule_mode(sched_mode))
end

local function get_time_option()
{
	pos_date=$(expr match "$led_schedule_mode" ".*DATE$")
	pos_time=$(expr match "$led_schedule_mode" ".*TIME$")
	pos_dow=$(expr match "$led_schedule_mode" ".*DOW")

	[ "$pos_date" -eq "0" ] && [ "$pos_time" -eq "0" ] && [ "$pos_dow" -eq "0" ] && return 1
	[ "$pos_date" -gt "0" ] && echo "DATE"
	[ "$pos_time" -gt "0" ] && echo "TIME"
	[ "$pos_dow" -gt "0" ] && echo "DOW"
	return 0
}

get_schedule_action()
{
	pos_active=$(expr match "$led_schedule_mode" "\bACTIVE.*")
	pos_standby=$(expr match "$led_schedule_mode" "\bSTANDBY.*")
	[ "$pos_active" -eq "0" ] && [ "$pos_standby" -eq "0" ] && return 1
	[ "$pos_active" -gt "0" ] && echo "ACTIVE"
	[ "$pos_standby" -gt "0" ] && echo "STANDBY"
	return 0
}

parse_schedule_mode_and_action()
{
	option="$(get_time_option)"
	action="$(get_schedule_action)"
}

get_now()
{
	option="$(get_time_option)"
	[ "$?" -eq "0" ] &&
	{
		if [ "$option" = "DATE" ]; then
			now="$(date +%Y%m%d%H%M)"
		else
			now="$(date +%H%M)"
		fi
	}
	echo "$now"
}

check_weekday_in_schedule()
{
	# If time option is not weekday, ignores
	[ "$option" = "DOW" ] || return 0

	today_weekday="$(date +%w)"
	get_schedule_day_of_week

    for weekday in $led_schedule_dow; do
		dow="$(dereference_day_of_week $weekday)"
        if [ "$today_weekday" = "$dow" ]; then
            return 0
        fi
    done
    return 1
}

# Function to get scheduled days of week (0 is Sunday and 6 Friday)
get_schedule_day_of_week()
{
	led_schedule_dow="$(uci get -q leds.scheduling.weekdays)"
}

get_complement_action()
{
	[ "$action" = "ACTIVE" ] && echo "STANDBY"
	[ "$action" = "STANDBY" ] && echo "ACTIVE"
	return 0
}

get_led_schedule()
{
	# Get schedule intervals
	intervals="$(uci get -q leds.scheduling.intervals)"


	if [ -z "$intervals" ]; then
		print_error_msg "Cannot have empty schedule intervals if mode is not ACTIVE neither STANDBY"
		return 1
	fi

	# Abort if scheduling information is invalid
	[ "$start" -ge "$end" ] && return 1

	return 0
}

get_current_led_schedule()
{
	# Get current LED schedule status
	led_schedule_status="$(cat /usr/sbin/cal/led_schedule)"
}

record_led_schedule()
{
	echo "$1" > /usr/sbin/cal/led_schedule
}

schedule_led()
{
	action="$(get_schedule_action)"
	complement_action="$(get_complement_action)"

	# First of all, check if action is simple mode (no schedule info required)
	[ "$1" = "SIMPLE" ] && { record_led_schedule "$action"; return 1; }

	# If time option is day of week schedule, check if today weekday is in the range
	if ! check_weekday_in_schedule ; then
		# Fake now and end times to force complement action
		end="0"
		now="1"
	fi

counter=0
for time in $intervals; do
	counter=$((counter+1))

	if [ "$((counter%2))" -eq 0 ]; then
		end="$time"
	else
		start="$time"
		continue
	fi

	# Then check if schedule is in between start and end times
	if [ "$start" -le "$now" ] && [ "$end" -ge "$now" ]; then
		[ "$led_schedule_status" = "$complement_action" ]  && record_led_schedule "$action"
		return
	fi
done

[ "$led_schedule_status" = "$action" ] && record_led_schedule "$complement_action"

}

start_schedule()
{
while true; do
	sleep $time_step
	if is_led_schedule_enabled && get_led_schedule_mode; then
		# If led schedule mode is only ACTIVE or STANDBY we don't need to check times
		if [ "$led_schedule_mode" = "ACTIVE" ] || [ "$led_schedule_mode" = "STANDBY" ]; then
			action_mode="SIMPLE"
		else
			if ! get_led_schedule; then
				continue
			fi
			get_current_led_schedule
			get_now
		fi
		schedule_led "$action_mode"
	fi
done
}

start()
{
	start_schedule&
}
