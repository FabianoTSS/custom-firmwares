#!/bin/sh

# exec ash
exec /bin/ash --login


