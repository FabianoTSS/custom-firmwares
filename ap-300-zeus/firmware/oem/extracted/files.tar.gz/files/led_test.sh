#!/bin/sh

[ -e /usr/sbin/cal/led_ctrl ] && {
        # Get LED_CTRL Status
	while [  -e /usr/sbin/cal/led_ctrl ] ; do
		LED_CTRL="$(cat /usr/sbin/cal/led_ctrl)"
		if [ $LED_CTRL = "random" ]
		then
			# BLUE Led ON
        		echo 16 > /sys/class/leds/ap953x\:blue\:signal1/delay_on
	        	echo 16 > /sys/class/leds/ap953x\:blue\:signal1/delay_off
		        sleep 1

			# RED Led ON and BLUE Led OFF
		        echo 8 > /sys/class/leds/ap953x\:blue\:signal1/delay_on
		        echo 8 > /sys/class/leds/ap953x\:blue\:signal1/delay_off
		        echo 16 > /sys/class/leds/ap953x\:red\:signal3/delay_on
		        echo 16 > /sys/class/leds/ap953x\:red\:signal3/delay_off
		        sleep 1

			# GREEN Led ON AND RED Led OFF
		        echo 8 > /sys/class/leds/ap953x\:red\:signal3/delay_on
		        echo 8 > /sys/class/leds/ap953x\:red\:signal3/delay_off
		        echo 16 > /sys/class/leds/ap953x\:green\:signal2/delay_on
		        echo 16 > /sys/class/leds/ap953x\:green\:signal2/delay_off
        		sleep 1

			# GREEN Led OFF
			echo 8 > /sys/class/leds/ap953x\:green\:signal2/delay_on
			echo 8 > /sys/class/leds/ap953x\:green\:signal2/delay_off
		else
	                # Control Leds to change color to WHITE
	                echo 16 > /sys/class/leds/ap953x\:blue\:signal1/delay_on
	                echo 16 > /sys/class/leds/ap953x\:blue\:signal1/delay_off
	                echo 16 > /sys/class/leds/ap953x\:red\:signal3/delay_on
	                echo 16 > /sys/class/leds/ap953x\:red\:signal3/delay_off
	                echo 16 > /sys/class/leds/ap953x\:green\:signal2/delay_on
	                echo 16 > /sys/class/leds/ap953x\:green\:signal2/delay_off
			sleep 1
		fi
	done
}
