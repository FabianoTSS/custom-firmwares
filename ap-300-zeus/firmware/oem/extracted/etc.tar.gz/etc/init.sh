#!/bin/sh
chroot /chroot /sbin/getty ttyS0 57600 
