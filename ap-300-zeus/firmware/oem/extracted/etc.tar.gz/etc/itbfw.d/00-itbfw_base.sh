#!/bin/sh

#### itbfw base ########################################################
#
#  This sets a base for custom firewall by delegating from internal 
# to custom chains as well as speed up flow for URL filtering.
#
########################################################################

# Global variables
. /lib/functions/itbfw_variables.sh
TRUE=1
FALSE=0
HAS_IP6T=$FALSE

# General definitions
FW_END_COUNTER=0x9000
FW_MASK=0xF000
FW_MARK_DROP=0x1000
FW_MARK_ACCEPT=0x2000

# Chains
HTTP_ALLOW="http_allow_itb"
HTTP_DROP="http_drop_itb"
HANDLE_URL="handle_url_itb"

# Chamadas de sistema
WAN_IFNAME=`. /lib/functions/network.sh; network_get_device if_wan wan; echo $if_wan`

#### Examples ##########################################################
#
# Allow URL
# $IPT_MANGLE -A $HTTP_ALLOW -m string --string "intelbras.com.br" $STRING_ALGO -j $CHAIN_ALLOW_MARK
#
# Drop URL
# $IPT_MANGLE -A $HTTP_DROP -m string --string "intelbras.com.br" $STRING_ALGO -j $CHAIN_DROP_MARK
#
########################################################################

_find_ip6t() {
	if ! [ -x "$(command -v ip6tables)" ]; then
		HAS_IP6T=$FALSE
		return
	fi

	HAS_IP6T=$TRUE
	return
}

ebt_delegate_clean() {
	# ebtables
	# Clean chains
	$EBT_BROUTE -F $CHAIN_PREROUTING_ITB >&- 2>&-
	$EBT_BROUTE -D BROUTING -j $CHAIN_PREROUTING_ITB >&- 2>&-
	$EBT_NAT -F $CHAIN_PREROUTING_ITB >&- 2>&-
	$EBT_NAT -D PREROUTING -j $CHAIN_PREROUTING_ITB >&- 2>&-
	$EBT_NAT -F $CHAIN_POSTROUTING_ITB >&- 2>&-
	$EBT_NAT -D POSTROUTING -j $CHAIN_POSTROUTING_ITB >&- 2>&-
	$EBT_FILTER -F $CHAIN_FORWARD_ITB >&- 2>&-
	$EBT_FILTER -D FORWARD -j $CHAIN_FORWARD_ITB >&- 2>&-

	# Delete chains
	$EBT_BROUTE -X $CHAIN_PREROUTING_ITB >&- 2>&-
	$EBT_NAT -X $CHAIN_PREROUTING_ITB >&- 2>&-
	$EBT_NAT -X $CHAIN_POSTROUTING_ITB >&- 2>&-
	$EBT_FILTER -X $CHAIN_FORWARD_ITB
}

ebt_delegate_set() {
	# ebtables
	# Create chains
	$EBT_BROUTE -N $CHAIN_PREROUTING_ITB
	$EBT_NAT -N $CHAIN_PREROUTING_ITB
	$EBT_NAT -N $CHAIN_POSTROUTING_ITB
	$EBT_FILTER -N $CHAIN_FORWARD_ITB

	# Define policy
	$EBT_BROUTE -P $CHAIN_PREROUTING_ITB RETURN
	$EBT_NAT -P $CHAIN_PREROUTING_ITB RETURN
	$EBT_NAT -P $CHAIN_POSTROUTING_ITB RETURN
	$EBT_FILTER -P $CHAIN_FORWARD_ITB RETURN


	# Delegate
	$EBT_BROUTE -I BROUTING -j $CHAIN_PREROUTING_ITB
	$EBT_NAT -I PREROUTING -j $CHAIN_PREROUTING_ITB
	$EBT_NAT -I POSTROUTING -j $CHAIN_POSTROUTING_ITB
	$EBT_FILTER -I FORWARD -j $CHAIN_FORWARD_ITB
}

ipt_delegate_clean() {
	# Clean chains
	$IPT_MANGLE -F $CHAIN_PREROUTING_ITB >&- 2>&-
	$IPT_MANGLE -D PREROUTING -j $CHAIN_PREROUTING_ITB >&- 2>&-
	$IPT_MANGLE -F $CHAIN_POSTROUTING_ITB >&- 2>&-
	$IPT_MANGLE -D POSTROUTING -j $CHAIN_POSTROUTING_ITB >&- 2>&-
	$IPT_MANGLE -F $CHAIN_FORWARD_ITB >&- 2>&-
	$IPT_MANGLE -D FORWARD -o $WAN_IFNAME -j $CHAIN_FORWARD_ITB >&- 2>&-
	$IPT_MANGLE -F $HANDLE_URL >&- 2>&-
	$IPT_MANGLE -F $CHAIN_WALLED_GARDEN >&- 2>&-
	$IPT_MANGLE -F $HTTP_ALLOW >&- 2>&-
	$IPT_MANGLE -F $HTTP_DROP >&- 2>&-
	$IPT_MANGLE -F $CHAIN_ALLOW_MARK >&- 2>&-
	$IPT_MANGLE -F $CHAIN_DROP_MARK >&- 2>&-
	$IPT_FILTER -F $CHAIN_FORWARD_ITB >&- 2>&-
	$IPT_FILTER -D FORWARD -j $CHAIN_FORWARD_ITB >&- 2>&-
	$IPT_FILTER -F $CHAIN_INPUT_ITB >&- 2>&-
	$IPT_FILTER -D INPUT -j $CHAIN_INPUT_ITB >&- 2>&-

	# Delete chains
	$IPT_MANGLE -X $CHAIN_PREROUTING_ITB >&- 2>&-
	$IPT_MANGLE -X $CHAIN_POSTROUTING_ITB >&- 2>&-
	$IPT_MANGLE -X $CHAIN_FORWARD_ITB >&- 2>&-
	$IPT_MANGLE -X $HANDLE_URL >&- 2>&-
	$IPT_MANGLE -X $CHAIN_WALLED_GARDEN >&- 2>&-
	$IPT_MANGLE -X $HTTP_ALLOW >&- 2>&-
	$IPT_MANGLE -X $HTTP_DROP >&- 2>&-
	$IPT_MANGLE -X $CHAIN_ALLOW_MARK >&- 2>&-
	$IPT_MANGLE -X $CHAIN_DROP_MARK >&- 2>&-
	$IPT_FILTER -X $CHAIN_FORWARD_ITB >&- 2>&-
	$IPT_FILTER -X $CHAIN_INPUT_ITB >&- 2>&-


	[ $HAS_IP6T -eq $FALSE ] && {
		$IPT_NAT -F $CHAIN_PREROUTING_ITB >&- 2>&-
		$IPT_NAT -D PREROUTING -j $CHAIN_PREROUTING_ITB >&- 2>&-
		$IPT_NAT -F $CHAIN_POSTROUTING_ITB >&- 2>&-
		$IPT_NAT -D POSTROUTING -j $CHAIN_POSTROUTING_ITB >&- 2>&-
		$IPT_NAT -F $CHAIN_CP_GENERAL_RULES_ITB >&- 2>&-

		$IPT_NAT -X $CHAIN_PREROUTING_ITB >&- 2>&-
		$IPT_NAT -X $CHAIN_POSTROUTING_ITB >&- 2>&-
		$IPT_NAT -X $CHAIN_CP_GENERAL_RULES_ITB >&- 2>&-
	}
}

ipt_delegate_set() {
	# Create chains
	$IPT_MANGLE -N $CHAIN_PREROUTING_ITB
	$IPT_MANGLE -N $CHAIN_POSTROUTING_ITB
	$IPT_MANGLE -N $CHAIN_FORWARD_ITB
	$IPT_MANGLE -N $HANDLE_URL
	$IPT_MANGLE -N $CHAIN_WALLED_GARDEN
	$IPT_MANGLE -N $HTTP_ALLOW
	$IPT_MANGLE -N $HTTP_DROP
	$IPT_MANGLE -N $CHAIN_ALLOW_MARK
	$IPT_MANGLE -N $CHAIN_DROP_MARK
	$IPT_FILTER -N $CHAIN_FORWARD_ITB
	$IPT_FILTER -N $CHAIN_INPUT_ITB

	$IPT_MANGLE -I PREROUTING -j $CHAIN_PREROUTING_ITB >&- 2>&-
	$IPT_MANGLE -I POSTROUTING -j $CHAIN_POSTROUTING_ITB >&- 2>&-
	$IPT_MANGLE -I FORWARD -o $WAN_IFNAME -j $CHAIN_FORWARD_ITB >&- 2>&-
	$IPT_FILTER -I FORWARD -j $CHAIN_FORWARD_ITB >&- 2>&-
	$IPT_FILTER -I INPUT -j $CHAIN_INPUT_ITB >&- 2>&-

	[ $HAS_IP6T -eq $FALSE ] && {
		$IPT_NAT -N $CHAIN_PREROUTING_ITB
		$IPT_NAT -N $CHAIN_POSTROUTING_ITB
		$IPT_NAT -N $CHAIN_CP_GENERAL_RULES_ITB
		$IPT_NAT -I PREROUTING -j $CHAIN_PREROUTING_ITB >&- 2>&-
		$IPT_NAT -I POSTROUTING -j $CHAIN_POSTROUTING_ITB >&- 2>&-
	}

}

# iptables forward - Speed up URL filter
ipt_forward_set() {
	# marks
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -j CONNMARK --restore-mark --mask $FW_MASK
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -m mark --mark $FW_MARK_DROP/$FW_MASK -j RETURN
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -m mark --mark $FW_MARK_ACCEPT/$FW_MASK -j RETURN
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -m mark --mark $FW_END_COUNTER/$FW_MASK -j RETURN
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -p tcp --dport 80  -j $HANDLE_URL
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -p tcp --dport 443 -j $HANDLE_URL
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -p tcp --dport 443 -j $CHAIN_WALLED_GARDEN
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -m mark --mark 0x8000/$FW_MASK -j MARK --set-mark $FW_END_COUNTER/$FW_MASK
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -m mark --mark 0x7000/$FW_MASK -j MARK --set-mark 0x8000/$FW_MASK
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -m mark --mark 0x6000/$FW_MASK -j MARK --set-mark 0x7000/$FW_MASK
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -m mark --mark 0x5000/$FW_MASK -j MARK --set-mark 0x6000/$FW_MASK
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -m mark --mark 0x4000/$FW_MASK -j MARK --set-mark 0x5000/$FW_MASK
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -m mark --mark 0x3000/$FW_MASK -j MARK --set-mark 0x4000/$FW_MASK
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -m mark --mark 0x0000/$FW_MASK -j MARK --set-mark 0x3000/$FW_MASK
	$IPT_MANGLE -A $CHAIN_FORWARD_ITB -j CONNMARK --save-mark

	# Filter
	$IPT_FILTER -A $CHAIN_FORWARD_ITB -m mark --mark $FW_MARK_DROP/$FW_MASK -j DROP
	$IPT_FILTER -A $CHAIN_FORWARD_ITB -m mark --mark $FW_MARK_ACCEPT/$FW_MASK -j ACCEPT
}

# URL
ipt_url_set() {
	$IPT_MANGLE -A $HANDLE_URL -j $HTTP_ALLOW
	$IPT_MANGLE -A $HANDLE_URL -j $HTTP_DROP
}

ipt_allow_CHAIN_DROP_MARK_set() {
	# CHAIN_ALLOW_MARK_itb
	$IPT_MANGLE -A $CHAIN_ALLOW_MARK -j MARK --set-mark $FW_MARK_ACCEPT/$FW_MASK
	$IPT_MANGLE -A $CHAIN_ALLOW_MARK -j CONNMARK --save-mark
	$IPT_MANGLE -A $CHAIN_ALLOW_MARK -j RETURN

	# CHAIN_DROP_MARK_itb
	$IPT_MANGLE -A $CHAIN_DROP_MARK -j MARK --set-mark $FW_MARK_DROP
	$IPT_MANGLE -A $CHAIN_DROP_MARK -j CONNMARK --save-mark
	$IPT_MANGLE -A $CHAIN_DROP_MARK -j ACCEPT
}

start_base_ebt() {
	ebt_delegate_clean
	ebt_delegate_set
}

start_base_ipt() {
	IPT_MANGLE="ip${1}tables -t mangle"
	IPT_NAT="ip${1}tables -t nat"
	IPT_FILTER="ip${1}tables -t filter"

	ipt_delegate_clean
	ipt_delegate_set
	ipt_forward_set
	ipt_url_set
	ipt_allow_CHAIN_DROP_MARK_set
}


start_base_ebt
start_base_ipt

_find_ip6t
[ $HAS_IP6T -eq $TRUE ] && start_base_ipt '6'
