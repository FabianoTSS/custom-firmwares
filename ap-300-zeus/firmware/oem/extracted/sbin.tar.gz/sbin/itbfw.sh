#!/bin/sh

. /lib/functions/itbfw.sh

# Waits for all services that depends on itbfw to finish
wait_services_locks () {
	# It might take couple of seconds for the config change event kick in
	sleep 2
	while [ "$(ls ${ITBFW_LOCK_DIR})" ]
	do
		sleep 1;
	done
}

fw_enabled=`uci get firewall.@defaults[0].enabled`
[ $fw_enabled -eq 0 ] && exit 0

[ "$1" = "reload" ] && {
	wait_services_locks
	fw3 -q reload
	exit 0
}

# Protection against concurrent calls
(
	flock -x 9;
	for i in /etc/itbfw.d/* ; do
		[ -x $i ] && $i
	done
) 9>/tmp/lock/.itbfw_running;
