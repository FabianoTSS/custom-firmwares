#!/bin/sh
#
# Copyright (C) 2009-2011 OpenWrt.org
#

RAMIPS_BOARD_NAME=ap300
RAMIPS_MODEL="AP 300"

ramips_board_detect() {
	[ -e "/tmp/sysinfo/" ] || mkdir -p "/tmp/sysinfo/"

	echo "$RAMIPS_BOARD_NAME" > /tmp/sysinfo/board_name
	echo "$RAMIPS_MODEL" > /tmp/sysinfo/model
}

ramips_board_name() {
	local name

	[ -f /tmp/sysinfo/board_name ] && name=$(cat /tmp/sysinfo/board_name)
	[ -z "$name" ] && name="unknown"

	echo "$name"
}

ramips_model_name() {
	local name

	[ -f /tmp/sysinfo/model ] && name=$(cat /tmp/sysinfo/model)
	[ -z "$name" ] && name="unknown"

	echo "$name"
}
