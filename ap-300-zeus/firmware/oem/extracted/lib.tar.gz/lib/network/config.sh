#!/bin/sh
# Copyright (C) 2011 OpenWrt.org

. /usr/share/libubox/jshn.sh

find_config() {
	local device="$1"
	local ifdev ifl3dev ifobj
	for ifobj in `ubus list network.interface.\*`; do
		interface="${ifobj##network.interface.}"
		(
			json_load "$(ifstatus $interface)"
			json_get_var ifdev device
			json_get_var ifl3dev l3_device
			if [[ "$device" = "$ifdev" ]] || [[ "$device" = "$ifl3dev" ]]; then
				exit 0
			else
				exit 1
			fi
		) && return
	done
}

unbridge() {
	return
}

ubus_call() {
	json_init
	local _data="$(ubus -S call "$1" "$2")"
	[ -z "$_data" ] && return 1
	json_load "$_data"
	return 0
}

get_device_names() {
	# ifname = $1
	# l3_device dest = $2
	# device dest = $3
	# stop_recursive = $4
	local device l3_device
	ubus_call "network.interface.$1" status || return 1
	json_get_var l3_device l3_device
	json_get_var device device
	eval "$2=\"$device\""
	eval "$3=\"$l3_device\""
	return
}

fixup_interface() {
	# ifname=$1
	# is_relayd=$2

	local config="$1"
	local ifname type device l3dev dev

	config_get type "$config" type
	config_get ifname "$config" ifname
	config_get device "$config" device "$ifname"
	[ "bridge" = "$type" ] && ifname="br-$config"
	config_set "$config" device "$ifname"
	get_device_names "$config" dev l3dev
	[ \( "$2" = "1" \) -a \( \( -z "$l3dev" \) -o \( -z "$dev" \) \) ] && {
		sleep 10
		get_device_names "$config" dev l3dev
		[ \( -z "$l3dev" \) -a \( "$config" == "wwan" \) -a \( -n "$dev" \) ] && {
			wwan_ip=$(uci get -q network.wwan.ipaddr)
			wwan_netmask=$(uci get -q network.wwan.netmask)
			[ \( -n "$wwan_ip" \) -a \( -n "$wwan_netmask" \) ] && ifconfig $dev $wwan_ip netmask $wwan_netmask
		}
	}
	[ -n "$l3dev" ] && ifname="$l3dev"
	[ \( -z "$device" \) -a \( -n "$dev" \) ] && device="$dev"
	json_init
	[ -n "$ifname" ] && config_set "$config" ifname "$ifname" || config_set "$config" ifname "$dev"
	config_set "$config" device "$device"
}

scan_interfaces() {
	config_load network
	config_foreach fixup_interface interface
}

prepare_interface_bridge() {
	local config="$1"

	[ -n "$config" ] || return 0
	ubus call network.interface."$config" prepare
}

setup_interface() {
	local iface="$1"
	local config="$2"

	[ -n "$config" ] || return 0
	ubus call network.interface."$config" add_device "{ \"name\": \"$iface\" }"
}

do_sysctl() {
	[ -n "$2" ] && \
		sysctl -n -e -w "$1=$2" >/dev/null || \
		sysctl -n -e "$1"
}
