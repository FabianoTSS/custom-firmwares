#!/bin/sh

ITBFW_LOCK_DIR="/tmp/lock/itbfw"

itbfw_lock () {
	mkdir -p ${ITBFW_LOCK_DIR}/${1} > /dev/null 2>&1
}

itbfw_unlock () {
	rmdir ${ITBFW_LOCK_DIR}/${1} > /dev/null 2>&1
}
