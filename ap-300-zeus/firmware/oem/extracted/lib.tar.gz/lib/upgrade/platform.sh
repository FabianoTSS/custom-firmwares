#
# Copyright (C) 2011 OpenWrt.org
#

. /lib/functions/system.sh
. /lib/ramips.sh

PART_NAME=firmware
RAMFS_COPY_DATA=/lib/ramips.sh

itb_get_magic () {
	(get_image "$@" | dd bs=4 skip=4 count=1 | hexdump -v -n 4 -e '1/1 "%02x"') 2>/dev/null
}

get_image_md5 () {
	(get_image "$@" | dd bs=16 count=1 | hexdump -v -n 16 -e '1/1 "%02x"') 2>/dev/null
}

calc_image_md5 () {
	(get_image "$@" | dd ibs=16 skip=1 | md5sum -b -) 2>/dev/null
}

check_image_md5 () {
	local md5_img=$(get_image_md5 "$1")
	local md5_chk=$(calc_image_md5 "$1")
	md5_chk="${md5_chk%% *}"

	if [ -n "$md5_img" -a -n "$md5_chk" ] && [ "$md5_img" = "$md5_chk" ]; then
		return 0
	else
		echo "Image file is corrupted."
		return 1
	fi
}

platform_check_image() {
	local board=$(ramips_board_name)
	local magic_long="$(itb_get_magic "$1")"
	local image_check=NOK

	[ "$#" -gt 1 ] && return 1

	case "$board" in
	ap300)
		[ "$magic_long" = "d80db2a1" ] && {
			image_check=OK
		}
		;;
	*)
		image_check=ND
		;;
	esac

    case "$image_check" in
	OK)
		check_image_md5 $1
		return $?
		;;
	NOK)
		echo "Invalid image type."
		return 1
		;;
	ND)
		echo "Sysupgrade is not yet supported on $board."
		return 1
		;;
	esac
}

platform_do_upgrade() {
	sync
	if [ "$SAVE_CONFIG" -eq 1 ]; then
		get_image "$ARGV" | dd ibs=20 skip=1 2>/dev/null | mtd $MTD_CONFIG_ARGS -j "$CONF_TAR" write - "${PART_NAME:-image}"
	else
		get_image "$ARGV" | dd ibs=20 skip=1 2>/dev/null | mtd write - "${PART_NAME:-image}"
	fi
}

disable_watchdog() {
	killall watchdog
	( ps | grep -v 'grep' | grep '/dev/watchdog' ) && {
		echo 'Could not disable watchdog'
		return 1
	}
}

append sysupgrade_pre_upgrade disable_watchdog
