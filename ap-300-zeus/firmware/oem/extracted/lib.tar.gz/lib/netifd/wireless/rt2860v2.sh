#!/bin/sh
. /lib/netifd/netifd-wireless.sh
. /lib/functions/system.sh
. /lib/ramips.sh

g_phy=0
config_file=/tmp/rt2860.dat
modules=rt2860v2_ap
rt2860apd=rt2860apd
prefix_apcli=apcli
prefix_ra=ra

init_wireless_driver "$@"

Debug() {
	local params="$@"

#	echo "RT2860V2: $params" > /dev/console
#	logger -s -t rt2860v2 "$params"
}

InitConfigFile() {
	Debug "Zerando arquivo $config_file"
	> $config_file
}

AddConfigOption() {
	local option=$1
	local value=$2

	op=$([ "$value" == "empty_option" ] && echo $option || echo "$option=$value")
	echo "$op" >> $config_file
#	Debug "ADD Option: $op"
}

UpdateConfigOption() {
	local option=$1
	local value=$2
	local aux

	value=$(echo "$value" | sed -e 's/[\/&]/\\&/g')

	aux=`grep "^$option=" $config_file`
	if [ -z $aux ]; then
		AddConfigOption $option "$value"
	else
		aux=$(echo "$aux" | cut -d= -f2 | sed -e 's/[\/&]/\\&/g')
		cat $config_file | sed "s/^$option=.*$/$option=$aux;$value/g" > $config_file.BKP
		mv $config_file.BKP $config_file
	fi
}

GetConfigOption() {
	local option=$1

	echo "`grep "^$option=" $config_file|cut -d= -f2`"
}

ChangeConfigOption() {
	local option=$1
	local value=$2
	local aux

	aux=`grep "^$option=" $config_file`
	if [ -z $aux ]; then
		AddConfigOption $option "$value"
	else
		cat $config_file | sed "s/^$option=.*$/$option=$value/g" > $config_file.BKP
		mv $config_file.BKP $config_file
	fi
}

InsMod() {
	Debug "Inserindo modulo $modules"
	modprobe $modules
	sleep 2
}

RmMod() {
	Debug "Removendo modulo $modules"
	mod=`lsmod|grep rt2860v2`
	if [ -n "$mod" ]; then
		BssidNum=$(GetConfigOption BssidNum)
		if [ -n "$BssidNum" ]; then
			i=0
			while [ $i -lt $BssidNum ]
			do 
				Debug "Fazendo down de (${prefix_ra}$i)"
				ifconfig ${prefix_ra}$i down
				i=$(($i + 1))
			done
		fi
		ifconfig ${prefix_apcli}0 down
		[ $(HasRadius) -eq 1 ] && killall $rt2860apd
		rmmod $modules
	fi
}

GetCountryRegion() {
#	CountryRegion           {0~7} 
#	::Set country region                                     
#		0: 1 ~ 11 ch  //North America - FCC , Estados Unidos
#		1: 1 ~ 13 ch  //Europe, China, Australia - ETSI, Brasil, Argentina, Uruguay 
#		2: 10, 11 ch  // 
#		3: 10 ~ 13 ch 
#		4: 14 ch 
#		5: 1 ~ 14 ch //Japan - MKK
#		6: 3 ~ 9 ch 
#		7: 5 ~ 13 ch 
	local country=$1
	local countryRegion

	case $country in
		US) countryRegion=0;;
		JP) countryRegion=5;;
		 *) countryRegion=1;;
	esac
	echo $countryRegion
}

GetCountryCode() {
	local country=$1
	local countryCode

	case $country in
		CT) countryCode=0  ;;#COMPLIANCE_TEST
		AR) countryCode=32 ;;#ARGENTINA
		UY) countryCode=858;;#URUGUAY
		JP) countryCode=392;;#JAPAN
		BR) countryCode=76 ;;#BRAZIL
		US) countryCode=840;;#EUA
		MX) countryCode=484;;#MEXICO
		 *) countryCode=0  ;;
	esac
	echo $countryCode
}

GetWirelessMode() {
#0: legacy 11b/g mixed     
#1: legacy 11B only
#2: legacy 11A only // Not support in RfIcType=1(id=RFIC_5225) and RfIcType=2(id=RFIC_5325)
#3: legacy 11a/b/g mixed     // Not support in RfIcType=1(id=RFIC_5225) and RfIcType=2(id=RFIC_5325)
#4: legacy 11G only
#5: 11ABGN mixed
#6: 11N only
#7: 11GN mixed
#8: 11AN mixed
#9: 11BGN mixed
#10: 11AGN mixed
#11: 11N (5G)

	local hwmode=$1
	local htmode=$2
	local require_mode=$3
	local wireless_mode=0

	case $hwmode in
		g|ng)
			if [ -z $require_mode ]; then
				case $htmode in
					NONE) wireless_mode=0;;#b/g
					   *) wireless_mode=9;;#b/g/n
				esac
			elif [ "$require_mode" == "n" ]; then
				wireless_mode=6 #N
			else
				logger "Parametro desconhecido"
					fi
					;;
	a|ac)
		;;
	*)
		wireless_mode=1111
		;;
	esac
	echo $wireless_mode
}

GetAuthMode() {
	local encryption=$1
	local auth_type

	case "$encryption" in
		*psk2*) auth_type=WPA2PSK;;
		*psk*)  auth_type=WPAPSK;;
		*wpa2*) auth_type=WPA2;;
		*wpa*)  auth_type=WPA;;
		facebook_wifi|none|*8021x*) auth_type=OPEN;;
		*wep*)
			case "$encryption" in
				*shared*)
					auth_type=SHARED
				;;
				*)
					auth_type=OPEN
				#case AUTH_AUTO:
				#fprintf(ra_fp,"WEPAUTO");
				;;
			esac
		;;
		*) auth_type=OPEN;;
	esac
	echo $auth_type
}

HasRadius() {
	local str=$(GetConfigOption AuthMode)
	local hasRadius=0
	IFS=\;
	for i in $str
	do
		case $i in
			WPA|WPA2) hasRadius=1;;
		esac
	done
	IFS=' '
	echo $hasRadius
}

GetEncrypType() {
	local encryption=$1
	local enc_type

	case "$encryption" in
		none)  enc_type=NONE;;
		*wep*) enc_type=WEP;;
		*tkip*) enc_type=TKIP;;
 		*aes*|*ccmp*) enc_type=AES;;
		*)     enc_type=NONE;;
	esac
	echo $enc_type
}

GetAccessPolicy() {
	local policy=$1
#AccessPolicy0  0: Disabled; 1: Allow; 2: Deny
	if [ "$policy" == "allow" ]; then
		echo 1
	elif [ "$policy" == "deny" ]; then
		echo 2
	else
		echo 0
	fi
}

GetAccessControlList() {
	local maclist=$1
	local macs

	for i in $maclist; do
		macs="$macs$i;"
	done
	macs=`echo $macs|sed "s/;$//"`
	echo $macs
}
			
GetPreAuthifname() {
	local network=$1

	if [ "`uci get network.@network[0].mode`" == "router" ]
	then
		echo "`uci get network.wan.ifname`"
	else
		echo "br-$network"
	fi
}
			
Get_own_ip_addr() {
	local network=$1
	local iface=$(GetPreAuthifname $network)

	echo "`ifconfig $iface|grep "inet addr:"|cut -d: -f2|cut -d" " -f1`"
}

drv_rt2860v2_init_device_config() {
	Debug "drv_rt2860v2_init_device_config $@"
	config_add_string maxassoc_ap isolate_ssid
	config_add_string send_probe_req_event
	config_add_string country
	config_add_boolean country_ie doth
	config_add_string require_mode

	config_add_string path phy 'macaddr:macaddr'
	config_add_string channel opmode
	config_add_string hwmode
	config_add_int beacon_int chanbw frag rts maxtxpower mintxpower
	config_add_int rxantenna txantenna antenna_gain txpower distance
	config_add_boolean noscan require_wmm
	config_add_array ht_capab
	config_add_boolean \
	rxldpc \
	short_gi_80 \
	short_gi_160 \
	tx_stbc_2by1 \
	su_beamformer \
	su_beamformee \
	mu_beamformer \
	mu_beamformee \
	vht_txop_ps \
	htc_vht \
	rx_antenna_pattern \
	tx_antenna_pattern
	config_add_int vht_max_a_mpdu_len_exp vht_max_mpdu vht_link_adapt vht160 rx_stbc tx_stbc
	config_add_boolean \
	ldpc \
	greenfield \
	short_gi_20 \
	short_gi_40 \
	dsss_cck_40

}

drv_rt2860v2_init_iface_config() {
	Debug "drv_rt2860v2_init_iface_config $@"
	config_add_string 'bssid:macaddr' 'ssid:string' 'sensibility_signal:string' 'sensibility_interval:string' encryption 'key:wpakey' 'network:string'
	config_add_boolean wds wmm hidden

	config_add_int maxassoc max_inactivity
	config_add_boolean disassoc_low_ack isolate short_preamble
	
	config_add_int \
	wep_rekey eap_reauth_period \
	wpa_group_rekey wpa_pair_rekey wpa_master_rekey

	config_add_boolean rsn_preauth auth_cache
	config_add_int ieee80211w 

	config_add_string 'auth_server:host' 'server:host'
	config_add_string auth_secret 
	config_add_int 'auth_port:port' 'port:port'

	config_add_string acct_server
	config_add_string acct_secret
	config_add_int acct_port

	config_add_string dae_client
	config_add_string dae_secret
	config_add_int dae_port

	config_add_string nasid
	config_add_string ownip
	config_add_string iapp_interface
	config_add_string eap_type ca_cert client_cert identity auth priv_key priv_key_pwd

	config_add_int dynamic_vlan vlan_naming
	config_add_string vlan_tagged_interface

	config_add_string 'key1:wepkey' 'key2:wepkey' 'key3:wepkey' 'key4:wepkey' 'password:wpakey'

	config_add_boolean wps_pushbutton wps_label ext_registrar wps_pbc_in_m1
	config_add_string wps_device_type wps_device_name wps_manufacturer wps_pin

	config_add_int ieee80211w_max_timeout ieee80211w_retry_timeout

	config_add_string macfilter 'macfile:file'
	config_add_array 'maclist:list(macaddr)'

	config_add_int mcast_rate
	config_add_array basic_rate


	config_add_boolean wds powersave
	config_add_int maxassoc
	config_add_int max_listen_int
	config_add_int dtim_period


}

rt2860v2_prepare_vif() {
	local phy=$g_phy

	json_select config
	json_get_vars ifname mode ssid key encryption bssid \
	hidden macfilter port server sensibility_signal maxassoc isolate
	json_get_values maclist maclist
	json_get_values network network
	json_select ..

	# It is far easier to delete and create the desired interface
	case "$mode" in
		adhoc)
		;;
		ap)
			[ -n "$ifname" ] || ifname="${prefix_ra}${if_idx:-0}"
			if_idx=$((${if_idx:-0} + 1))
			AddConfigOption SSID$if_idx       "$ssid"
			AddConfigOption DefaultKeyID      2;1
			AddConfigOption Key1Str$if_idx    
			AddConfigOption Key2Str$if_idx    
			AddConfigOption Key3Str$if_idx    
			AddConfigOption Key4Str$if_idx    
			UpdateConfigOption MinimumStaSignal     $sensibility_signal
			if [ $if_idx -eq 1 ]; then
				AddConfigOption Key1Type          "1;0"
				AddConfigOption Key2Type          "1;0"
				AddConfigOption Key3Type          "1;0"
				AddConfigOption Key4Type          "1;0"
				AddConfigOption own_ip_addr       $(Get_own_ip_addr $network)
				AddConfigOption EAPifname         "br-$network"
				AddConfigOption PreAuthifname     $(GetPreAuthifname $network)
			fi
			AddConfigOption	   WPAPSK$if_idx                     "$key"
			UpdateConfigOption AuthMode                          $(GetAuthMode   "$encryption")
			UpdateConfigOption EncrypType                        $(GetEncrypType "$encryption")
			ChangeConfigOption BssidNum                          $([ "$(GetConfigOption BssidNum)" == "" ] && echo 1 || echo "`expr $(GetConfigOption BssidNum) + 1`")
			UpdateConfigOption HideSSID                          "$hidden"
			AddConfigOption    AccessPolicy$(($if_idx - 1))      $(GetAccessPolicy "$macfilter")
			AddConfigOption    AccessControlList$(($if_idx - 1)) $(GetAccessControlList "$maclist")
			UpdateConfigOption RADIUS_Server                     $([ "$server" == "" ] && echo "0.0.0.0" || echo "$server")
			UpdateConfigOption RADIUS_Port                       $([ "$port" == "" ] && echo "1812" || echo "$port")
			UpdateConfigOption RADIUS_Key                        $([ "$key" == "" ] && echo "0" || echo "$key")
			UpdateConfigOption MaxStaNum                         "$maxassoc"
			UpdateConfigOption NoForwarding                      "$isolate"
#	AddConfigOption WdsEnable 0
#	AddConfigOption WdsEncrypType NONE
#	AddConfigOption WdsPhyMode HTMIX
#	AddConfigOption WdsList=
#	AddConfigOption WdsKey=
		;;
		mesh)
		;;
		monitor)
		;;
		sta)
			ifname="${prefix_apcli}0"
			AddConfigOption ApCliEnable    1 
			AddConfigOption ApCliSsid      "$ssid"
			AddConfigOption ApCliBssid     $bssid
			AddConfigOption ApCliWPAPSK    "$key"
			AddConfigOption ApCliDefaultKeyID 2
			AddConfigOption ApCliAuthMode   $(GetAuthMode   $encryption)
			AddConfigOption ApCliEncrypType $(GetEncrypType $encryption)
			AddConfigOption ApCliKey1Type   1
			AddConfigOption ApCliKey1Str
			AddConfigOption ApCliKey2Type   1
			AddConfigOption ApCliKey2Str
			AddConfigOption ApCliKey3Type   1
			AddConfigOption ApCliKey3Str
			AddConfigOption ApCliKey4Type   1
			AddConfigOption ApCliKey4Str
		;;
	esac
	Debug "PREPARE_IF ifname($ifname) mode($mode) ssid($ssid) key($key) encryptio($encryptionn) bssid($bssid) opmode($opmode) hidden($hidden) macfilter($macfilter) port($port) server($server) network($network) if_idx($if_idx) phy($phy) todosparam($@) sensibility_signal($sensibility_signal)"
	json_add_object data
	json_add_string ifname "$ifname"
	json_close_object
	json_select config
	json_select ..
}

rt2860v2_setup_vif() {
	local name="$1"
	local failed

	json_select data
	json_get_vars ifname
	json_select ..

	json_select config
	json_get_vars mode
	json_get_var vif_txpower txpower

	Debug "rt2860v2_setup_vif name: $name todos:($@) ifname($ifname)"
	ifconfig "$ifname" up || {
	    wireless_setup_vif_failed IFUP_ERROR
	    json_select ..
	    return
    } 
	# wait VAP up before wireless_add_vif, which generates a notify to netifd

	json_select ..
	[ -n "$failed" ] || wireless_add_vif "$name" "$ifname"
	case "$mode" in
		ap)
			sleep 3
		;;
	esac
}

rt2860v2_interface_cleanup() {
	local phy="$1"
	Debug "rt2860v2_interface_cleanup phy: $phy ($@)"
	RmMod
}

drv_rt2860v2_cleanup() {
	Debug "drv_rt2860v2_cleanup $@"
	RmMod
}

drv_rt2860v2_setup() {
	g_phy=$1
	g_phy="${g_phy#*${prefix_ra}}"
	phy=$g_phy
	Debug "drv_rt2860v2_setup 1($1) phy($phy) todos($@)"
	ubus send itb '{"restarting_wifi":true}'

	json_select config
	json_get_vars \
		phy macaddr path \
		country chanbw distance \
		txpower antenna_gain \
		rxantenna txantenna \
		frag rts beacon_int htmode require_mode \
		channel maxtxpower noscan require_wmm opmode mintxpower	\
		maxassoc_ap isolate_ssid
	json_get_values basic_rate_list basic_rate
	json_select ..

	wireless_set_data phy="$phy"
	rt2860v2_interface_cleanup "$phy"

	set_default rxantenna all
	set_default txantenna all
	set_default distance 0
	set_default antenna_gain 0
	Debug "SETUP phy($phy) macaddr($macaddr) path($path) country($country) \
	      chanbw($chanbw) distance($distance) txpower($txpower) \
	      antena_gain($antenna_gain) rxantena($rxantenna) txantenna($txantenna) \
	      frags($frag) rts($rts) beacon_int($beacon_int) htmode($htmode) \
	      hwmode($hwmode) supported_mode($supported_mode) require_mode($require_mode) \
	      channel($channel) noscan($noscan) require_wmm($require_wmm) \
	      maxtxpower($maxtxpower) opmode($opmode) mintxpower($mintxpower) \
	      maxassoc_ap($maxassoc_ap) isolate_ssid($isolate_ssid)"

	InitConfigFile
	AddConfigOption Default            empty_option
	AddConfigOption CountryRegion      $(GetCountryRegion $country)
	AddConfigOption CountryCode        $(GetCountryCode   $country)
	AddConfigOption	WirelessMode       $(GetWirelessMode  $hwmode $htmode $require_mode)
	AddConfigOption CountryRegionABand $([ "$country" == "CT" ] && echo 22 || echo 7)
	AddConfigOption Channel            $([ "$channel" == "auto" ] && echo 0 || echo $channel)
	AddConfigOption AutoChannelSelect  $([ "$channel" == "auto" ] && echo 1 || echo 0)
	AddConfigOption	TxPreamble         0 # 0 long 1 short 
	AddConfigOption RTSThreshold       2346 
	AddConfigOption FragThreshold      2346
	AddConfigOption TxPower            100 
	AddConfigOption TxPowerMin         $mintxpower
	AddConfigOption TxPowerMax         $maxtxpower
	AddConfigOption TxPowerDec         "`expr $maxtxpower - $txpower`" 
	AddConfigOption TxPowerIwinfo      "$txpower" 
	AddConfigOption TxBurst            0 
	AddConfigOption PktAggregate       0 
	AddConfigOption TurboRate          0 
	AddConfigOption WmmCapable         $require_wmm
	AddConfigOption IEEE80211H         0 
	AddConfigOption MacAddress         $(macaddr_add $(cat /sys/class/net/eth0/address) +2)

	AddConfigOption HT_BW              $([ "${htmode:0:4}" == "HT40" ] && echo 1 || echo 0)
	AddConfigOption HT_RDG             0 
	AddConfigOption HT_EXTCHA          $([ "${htmode:4:1}" == "+" ] && echo 1 || echo 0)
	AddConfigOption	HT_OpMode          0 
	AddConfigOption HT_MpduDensity     0
	AddConfigOption HT_AutoBA          1
	AddConfigOption HT_AMSDU           1
	AddConfigOption	HT_BAWinSize       64
	AddConfigOption HT_GI              1
	AddConfigOption HT_MCS             33
	AddConfigOption HT_BADecline       0
	AddConfigOption HT_DisallowTKIP    0 
	AddConfigOption AutoFineTune       1
	AddConfigOption FineTuneSNR        0
	AddConfigOption FineTuneNoise      90
	AddConfigOption HT_BSSCoexistence  $([ "${noscan}" == "1" ] && echo 0 || echo 1)
	AddConfigOption DeviceName         "$(ramips_model_name)"
	AddConfigOption StreamMode         0 
	AddConfigOption BeaconPeriod       100
	AddConfigOption DtimPeriod         1
	AddConfigOption	DisableOLBC        0
	AddConfigOption TxAntenna          ""
	AddConfigOption RxAntenna          ""
	AddConfigOption APAifsn            "3;7;1;1"
	AddConfigOption	APCwmin            "4;4;3;2"
	AddConfigOption APCwmax            "6;10;4;3"
	AddConfigOption APTxop             "0;0;94;47"
	AddConfigOption APACM              "0;0;0;0"
	AddConfigOption BSSAifsn           "3;7;2;2"
	AddConfigOption BSSCwmin           "4;4;3;2"
	AddConfigOption BSSCwmax           "10;10;4;3"
	AddConfigOption BSSTxop            "0;0;94;47"
	AddConfigOption BSSACM             "0;0;0;0"
	AddConfigOption AckPolicy          "0;0;0;0"
	AddConfigOption APSDCapable        0
	AddConfigOption DLSCapable         0
	AddConfigOption EthWithVLANTag     0
	AddConfigOption MaxClients         $maxassoc_ap
	AddConfigOption NoForwardingBTNBSSID $isolate_ssid 
	AddConfigOption ShortSlot            1 
	AddConfigOption PreAuth              0 
	AddConfigOption RekeyInterval        0 
	AddConfigOption RekeyMethod          DISABLE 
	AddConfigOption PMKCachePeriod       10 
	AddConfigOption HSCounter            0 
	AddConfigOption IEEE8021X            0
	AddConfigOption HT_HTC               1
	AddConfigOption HT_LinkAdapt         1
	AddConfigOption HT_TxStream          2
	AddConfigOption HT_RxStream          2
	AddConfigOption IdleTimeout          300
	AddConfigOption RadioOn              $([ "${disabled}" == "0" ] && echo 0 || echo 1)

	for_each_interface "ap" rt2860v2_prepare_vif
	for_each_interface "sta adhoc mesh monitor" rt2860v2_prepare_vif
	InsMod	

	for_each_interface "ap" rt2860v2_setup_vif
	for_each_interface "sta adhoc mesh monitor" rt2860v2_setup_vif

	wireless_set_up

	[ $(HasRadius) -eq 1 ] && /bin/$rt2860apd
	ubus send itb '{"restarting_wifi":false}'
}

drv_rt2860v2_teardown() {
	local phy=$g_phy
	Debug "drv_rt2860v2_teardown $phy $@"
	wireless_process_kill_all

	json_select data
	json_get_vars phy
	json_select ..

	rt2860v2_interface_cleanup "$phy"
}

add_driver rt2860v2

